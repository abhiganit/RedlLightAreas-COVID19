There are 6 excel files one for each location:
1. India
2. Mumbai
3. Nagpur
4. Delhi
5. Kolkata
6. Pune

Excel file for each location has following statistics:
1. Cases
2. Cumulative cases
3. Hospitalization
4. Cumulative hospitalization
5. ICU admissions
6. Cumulative ICU admissions
7. Deaths
8. Cumulative deaths
For red-light area within:
9. Cases
10. Cumulative cases
11. Hospitalization
12. Cumulative hospitalization
13. ICU admissions
14. Cumulative ICU admissions
15. Deaths
16. Cumulative deaths

Each statistics are provided for R = 1.75, 2, 2.25 and 2.5 respectively under three scenarios:
1. No initial lockdown
2. Return to status quo after lockdown
3. Continued closure of red light area after lockdown



